Create databse Map;

create table dbo.Map
Id int,
 Name varchar(50),
 Latitude numeric(8,16),
 Longitude numeric(8,16),
 Description varchar(350),
 Location nvarchar(150);