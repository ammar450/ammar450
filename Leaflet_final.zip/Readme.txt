Requirements:
SQL Server 2012 or above
ASP.NET MVC 5 above framework

Steps:

1. Create a table server
2. Create a new MVC project and name it WebApplication.
3. Right click model folder and create a new item ADO.NET Entity Data model. (Name it and then click EF Designer From Data.)
4. Paste Controller file code into the controller.